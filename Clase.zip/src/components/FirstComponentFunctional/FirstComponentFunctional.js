const FirstComponentFunctional = () => {

    return (
        <div>
            <h2>Primer componente funcional</h2>
        </div>
    )

}

export default FirstComponentFunctional